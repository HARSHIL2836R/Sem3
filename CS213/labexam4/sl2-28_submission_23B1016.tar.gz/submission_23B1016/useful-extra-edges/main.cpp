// DO NOT MODIFY THIS FILE !!!

#include "useful-extra-edges.h"

int main() {
    Testcase testcase;
    testcase.getMinWeight();
}