#include "common.h"

using namespace std;

bool check_tree(unsigned n, vector<vector<int>> dist, vector<tuple<int, int, int>> &found_tree);
