# Graph Vizualization Tool

Credits: mxwell.github.io

## Usage

Open the `index.html` file in your browser. 

## Input Format

List the edges in separate lines. 

- Unweighted Graph: `u v`
- Weighted Graph: `u v w`