#include <bits/stdc++.h>
using namespace std;

long long cyclic_shifts(string s);

int32_t main() {

    // Don't edit this function

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    string s;
    cin>>s;

    cout<<cyclic_shifts(s)<<"\n";
    return 0;
}
