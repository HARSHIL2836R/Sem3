#include <iostream>
#include <array>
#include <map>
#include <set>
#include <vector>

using namespace std;
typedef long long ll;

vector<ll> find_num_min_paths(vector<vector<pair<int,int> > > &graph, int source);
