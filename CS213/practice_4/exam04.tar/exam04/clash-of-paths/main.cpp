// DO NOT MODIFY THIS FILE !!!

#include "clash-of-paths.h"

int main() {
    Testcase testcase;
    testcase.getNumNonClashWays();
}