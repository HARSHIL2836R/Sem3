#include "clash-of-paths.h"

/**
 * You can define any helper functions here. NO new "#include"s allowed.
 * 
 * You can access the adjacency list using the variable AdjacencyList.
 * Values of cities A and B are also member variables of the Testcase class.
 * 
 * Print the number of ways (mod 1e9+7) Alice and Bob can move such that 
 * they never "clash" at a city. Don't return anything.
 */

void Testcase::getNumNonClashWays() {
    // TODO: Write your code here
    
    // End TODO
}
