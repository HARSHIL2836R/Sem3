#include "huffman.h"

// Build Huffman Tree and generate codes
Node* buildHuffmanTree(const unordered_map<string, int>& freq, unordered_map<string, string>& huffmanCodes) {
    vector<Node*> minHeap;

    // Create leaf nodes for each pixel value with a frequency
    for (auto pair : freq) {
        insertNode(minHeap, new Node(pair.first, pair.second));
    }

    // Build the Huffman Tree

    //***********************//
    // Write your code here  //
    //***********************//

    while(minHeap.size() > 1) {
        Node* left = extractMin(minHeap);
        Node* right = extractMin(minHeap);
        Node* parent = new Node(left->freq + right->freq);
        parent->left = left;
        parent->right = right;
        insertNode(minHeap, parent);
    }


    // DO NOT EDIT LINES BELOW

    // Generate Huffman codes from the tree and prints them
    printCodes(minHeap[0], "", huffmanCodes);

    // Return the root of the tree
    return minHeap[0];
}

// Compress the image using the Huffman codes
string compressImage(const vector<vector<string>>& image, unordered_map<string, string>& huffmanCodes) {
    string compressedData = "";

    //***********************//
    // Write your code here  //
    //***********************//
    for (auto row : image) {
        for (const string& pixel : row) {
            compressedData += huffmanCodes[pixel];
        }
    }
    return compressedData;
}

// Decompress the data using the Huffman Tree
vector<vector<string>> decompressImage(const string& compressedData, Node* root, int rows, int cols, unordered_map<string, string> huffmanCodes) {
    vector<vector<string>> reconstructedImage(rows, vector<string>(cols, ""));

    //***********************//
    // Write your code here  //
    //***********************//

    unordered_map<string, string> reverseHuffmanCodes;
    for(auto pair : huffmanCodes) {
        reverseHuffmanCodes[pair.second] = pair.first;
    }

    int r = 0, c = 0;
    string code = "";
    for(auto &p : compressedData){
        code += p;
        if(reverseHuffmanCodes.find(code) != reverseHuffmanCodes.end()){
            reconstructedImage[r][c] = reverseHuffmanCodes[code];
            c++;
            if(c == cols){
                c = 0;
                r++;
            }
            code = "";
        }
    }

    return reconstructedImage;
}
